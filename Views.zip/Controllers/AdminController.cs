﻿using DABEvents.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DABEvents.Controllers
{
    public class AdminController : Controller
    {
        DABEventsEntities db = new DABEventsEntities();
        //
        // GET: /Admin/

        public ActionResult AdminIndex()
        {
            return View();
        }

        public ActionResult Users()
        {
            var db = new DABEventsEntities();
            var users = db.Users;
            return View(users);

        }

        public ActionResult Details(int id = 0)
        {
            User users = db.Users.Find(id);
            if (users == null)
            {
                return HttpNotFound();
            }
            return View(users);
        }

        public ActionResult BookingDetails()
        {
            var q = (from te in db.tbl_Events
                     join be in db.Book_Event on te.EventID equals be.EventID

                     select new
                     {
                         bookingid = be.BookingID,
                         userid = te.UserID,
                         eventtype = te.EventType,
                         venuetype = be.VenueType,
                         bookingdate = be.BookingDate,
                         noofguest = be.NoOfGuest,
                         dj = be.DJ,
                         speakers = be.Speakers,
                         mikes = be.Mikes,
                         normalsounds = be.NormalSounds,
                         banjo = be.Banjo,
                         lejms = be.Lejms,
                         band = be.Band,
                         orchestra = be.Orchestra,
                         snacks = be.Snacks,
                         foodtype = be.FoodType,
                         flower = be.Flower,
                         clothes = be.Clothes,
                         balloons = be.Balloons,
                         lights = be.Lights,
                         chairwithcover = be.ChairWithCover,
                         onlychairs = be.OnlyChairs,
                         sofas = be.Sofas,
                         tables = be.Tables,
                         invitationcard = be.InvitationCard,
                         identitycard = be.IdentityCard
                     }).ToList();
            List<BookEvent> bookevent = new List<BookEvent>();
            foreach (var te in q)
            {
                BookEvent b = new BookEvent();
                b.BookingID = te.bookingid;
                b.UserID = te.userid;
                b.EventType = te.eventtype;
                b.VenueType = te.venuetype;
                b.BookingDate = te.bookingdate;
                b.NoOfGuest = te.noofguest;
                b.DJ = te.dj;
                b.Speakers = te.speakers;
                b.Mikes = te.mikes;
                b.NormalSounds = te.normalsounds;
                b.Banjo = te.banjo;
                b.Lejms = te.lejms;
                b.Band = te.band;
                b.Orchestra = te.orchestra;
                b.Snacks = te.snacks;
                b.FoodType = te.foodtype;
                b.Flower = te.flower;
                b.Clothes = te.clothes;
                b.Balloons = te.balloons;
                b.Lights = te.lights;
                b.ChairWithCover = te.chairwithcover;
                b.OnlyChairs = te.onlychairs;
                b.Sofas = te.sofas;
                b.Tables = te.tables;
                b.InvitationCard = te.invitationcard;
                b.IdentityCard = te.identitycard;
                bookevent.Add(b);
            };

            return View(bookevent);
        }

        public ActionResult BookingDetails_Details(int id = 0)
        {
            //BookEvent bookevents = db.BookEvent.Find(id);
            BookEvent bookevent = new BookEvent();

            var q = (from te in db.tbl_Events
                     join be in db.Book_Event on te.EventID equals be.EventID
                     where id==be.BookingID
                     select new
                     {
                         bookingid = be.BookingID,
                         userid = te.UserID,
                         eventtype = te.EventType,
                         venuetype = be.VenueType,
                         bookingdate = be.BookingDate,
                         noofguest = be.NoOfGuest,
                         dj = be.DJ,
                         speakers = be.Speakers,
                         mikes = be.Mikes,
                         normalsounds = be.NormalSounds,
                         banjo = be.Banjo,
                         lejms = be.Lejms,
                         band = be.Band,
                         orchestra = be.Orchestra,
                         snacks = be.Snacks,
                         foodtype = be.FoodType,
                         flower = be.Flower,
                         clothes = be.Clothes,
                         balloons = be.Balloons,
                         lights = be.Lights,
                         chairwithcover = be.ChairWithCover,
                         onlychairs = be.OnlyChairs,
                         sofas = be.Sofas,
                         tables = be.Tables,
                         invitationcard = be.InvitationCard,
                         identitycard = be.IdentityCard
                     }).FirstOrDefault();
                         bookevent.BookingID=q.bookingid;
                         bookevent .UserID=q.userid;
                         bookevent. EventType=q.eventtype;
                         bookevent.VenueType=q.venuetype;
                         bookevent.BookingDate=q.bookingdate;
                         bookevent.NoOfGuest=q.noofguest;
                         bookevent.DJ=q.dj;
                         bookevent.Speakers=q.speakers;
                         bookevent.Mikes=q.mikes;
                         bookevent.NormalSounds=q.normalsounds;
                         bookevent.Banjo=q.banjo;
                         bookevent.Lejms=q.lejms;
                         bookevent.Band=q.band;
                         bookevent.Orchestra=q.orchestra;
                         bookevent.Snacks=q.snacks;
                         bookevent.FoodType=q.foodtype;
                         bookevent.Flower=q.flower;
                         bookevent.Clothes=q.clothes;
                         bookevent.Balloons=q.balloons;
                         bookevent.Lights=q.lights;
                         bookevent.ChairWithCover=q.chairwithcover;
                         bookevent.OnlyChairs=q.onlychairs;
                         bookevent.Sofas=q.sofas;
                         bookevent.Tables=q.tables;
                         bookevent.InvitationCard=q.invitationcard;
                         bookevent.IdentityCard = q.identitycard;
            if (q == null)
            {
                return HttpNotFound();
            }
            return View(bookevent);
        }

        //public ActionResult BookingDetails_Delete(int id = 0)
        //{
        //    Book_Event book_event = db.Book_Event.Find(id);
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(book_event);
        //}

        public ActionResult BookingDetails_Delete(int id = 0)
        {

            BookEvent bookevent = new BookEvent();

            var q = (from te in db.tbl_Events
                     join be in db.Book_Event on te.EventID equals be.EventID
                     where id == be.BookingID
                     select new
                     {
                         bookingid = be.BookingID,
                         userid = te.UserID,
                         eventtype = te.EventType,
                         venuetype = be.VenueType,
                         bookingdate = be.BookingDate,
                         noofguest = be.NoOfGuest,
                         dj = be.DJ,
                         speakers = be.Speakers,
                         mikes = be.Mikes,
                         normalsounds = be.NormalSounds,
                         banjo = be.Banjo,
                         lejms = be.Lejms,
                         band = be.Band,
                         orchestra = be.Orchestra,
                         snacks = be.Snacks,
                         foodtype = be.FoodType,
                         flower = be.Flower,
                         clothes = be.Clothes,
                         balloons = be.Balloons,
                         lights = be.Lights,
                         chairwithcover = be.ChairWithCover,
                         onlychairs = be.OnlyChairs,
                         sofas = be.Sofas,
                         tables = be.Tables,
                         invitationcard = be.InvitationCard,
                         identitycard = be.IdentityCard
                     }).FirstOrDefault();
            bookevent.BookingID = q.bookingid;
            bookevent.UserID = q.userid;
            bookevent.EventType = q.eventtype;
            bookevent.VenueType = q.venuetype;
            bookevent.BookingDate = q.bookingdate;
            bookevent.NoOfGuest = q.noofguest;
            bookevent.DJ = q.dj;
            bookevent.Speakers = q.speakers;
            bookevent.Mikes = q.mikes;
            bookevent.NormalSounds = q.normalsounds;
            bookevent.Banjo = q.banjo;
            bookevent.Lejms = q.lejms;
            bookevent.Band = q.band;
            bookevent.Orchestra = q.orchestra;
            bookevent.Snacks = q.snacks;
            bookevent.FoodType = q.foodtype;
            bookevent.Flower = q.flower;
            bookevent.Clothes = q.clothes;
            bookevent.Balloons = q.balloons;
            bookevent.Lights = q.lights;
            bookevent.ChairWithCover = q.chairwithcover;
            bookevent.OnlyChairs = q.onlychairs;
            bookevent.Sofas = q.sofas;
            bookevent.Tables = q.tables;
            bookevent.InvitationCard = q.invitationcard;
            bookevent.IdentityCard = q.identitycard;
            if (q == null)
            {
                return HttpNotFound();
            }
            return View(bookevent);
        }

        [HttpPost,ActionName("BookingDetails_Delete")]
        public ActionResult BookingDetails_DeleteConfirmed(int id)
        {
            Book_Event bookevent = db.Book_Event.Find(id);
            db.Book_Event.Remove(bookevent);
            db.SaveChanges();
            return RedirectToAction("BookingDetails");
        }

        public ActionResult ContactedUsers()
        {
            var db = new DABEventsEntities();
            var contactform = db.Contact_Form;
            return View(contactform);
        }

        public ActionResult ContactedUsers_Details(int id = 0)
        {
            Contact_Form contactform = db.Contact_Form.Find(id);
            if (contactform == null)
            {
                return HttpNotFound();
            }
            return View(contactform);
        }

        public ActionResult ContactedUsers_Delete(int id = 0)
        {
            Contact_Form contactform = db.Contact_Form.Find(id);
            if (contactform == null)
            {
                return HttpNotFound();
            }
            return View(contactform);
        }

        [HttpPost, ActionName("ContactedUsers_Delete")]
        public ActionResult ContactedUsers_DeleteConfirmed(int id)
        {
            Contact_Form contactform = db.Contact_Form.Find(id);
            db.Contact_Form.Remove(contactform);
            db.SaveChanges();
            return RedirectToAction("ContactedUsers");
        }
    }

}
