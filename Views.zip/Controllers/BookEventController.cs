﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DABEvents.Models;
using System.Net.Mail;
using System.Net;

namespace DABEvents.Controllers
{
    public class BookEventController : Controller
    {
        DABEventsEntities db = new DABEventsEntities();
        //
        // GET: /BookEvent/
        public ActionResult EventIndex()
        {
            return View();
        }

        public ActionResult BookEvent()
        {
            BookEvent eventModel = new BookEvent();
            tbl_Events objEvent = new tbl_Events();
            int intEvent;

            if (Session["EventID"] != null)
            {

                intEvent = Convert.ToInt32(Session["EventID"]);
               List<tbl_Events> q = (from s in db.tbl_Events where s.EventID == intEvent select s).ToList();
               
                   foreach (var tblevent in q)
                   {
                       if (q.Count() > 0)
                       {
                       objEvent.EventID = tblevent.EventID;
                       }
                       else
                       {
                           return HttpNotFound();
                       }
                   }
               
               
                

            }

            return View(eventModel);

        }

        [HttpPost]
        public ActionResult BookEvent(Book_Event BookEvent,FormCollection fc)
        {
            BookEvent eventModel = new BookEvent();
            ViewBag.Duplicate = "";
            int objCount = (from s in db.Book_Event
                                       where s.VenueType == BookEvent.VenueType && s.BookingDate ==BookEvent.BookingDate
                                       select s).Count();
            if (objCount > 0)
            {
                ViewBag.Duplicate = "Select another Date or Venue";
                return View(); }
            else
            {
               
                            if (!string.IsNullOrEmpty(fc["VenueType"]) && !string.IsNullOrWhiteSpace(fc["VenueType"]) &&
                                !string.IsNullOrEmpty(fc["DJ"]) && !string.IsNullOrWhiteSpace(fc["DJ"]) &&
                                !string.IsNullOrEmpty(fc["Speakers"]) && !string.IsNullOrWhiteSpace(fc["Speakers"]) &&
                                !string.IsNullOrEmpty(fc["Mikes"]) && !string.IsNullOrWhiteSpace(fc["Mikes"]) &&
                                !string.IsNullOrEmpty(fc["NormalSounds"]) && !string.IsNullOrWhiteSpace(fc["NormalSounds"]) &&
                                !string.IsNullOrEmpty(fc["Banjo"]) && !string.IsNullOrWhiteSpace(fc["Banjo"]) &&
                                !string.IsNullOrEmpty(fc["Lejms"]) && !string.IsNullOrWhiteSpace(fc["Lejms"]) &&
                                !string.IsNullOrEmpty(fc["Band"]) && !string.IsNullOrWhiteSpace(fc["Band"]) &&
                                !string.IsNullOrEmpty(fc["Orchestra"]) && !string.IsNullOrWhiteSpace(fc["Orchestra"]) &&
                                !string.IsNullOrEmpty(fc["Snacks"]) && !string.IsNullOrWhiteSpace(fc["Snacks"]) &&
                                !string.IsNullOrEmpty(fc["FoodType"]) && !string.IsNullOrWhiteSpace(fc["FoodType"]) &&
                                !string.IsNullOrEmpty(fc["Flower"]) && !string.IsNullOrWhiteSpace(fc["Flower"]) &&
                                !string.IsNullOrEmpty(fc["Clothes"]) && !string.IsNullOrWhiteSpace(fc["Clothes"]) &&
                                !string.IsNullOrEmpty(fc["Balloons"]) && !string.IsNullOrWhiteSpace(fc["Balloons"]) &&
                                !string.IsNullOrEmpty(fc["Lights"]) && !string.IsNullOrWhiteSpace(fc["Lights"]) &&
                                !string.IsNullOrEmpty(fc["ChairWithCover"]) && !string.IsNullOrWhiteSpace(fc["ChairWithCover"]) &&
                                !string.IsNullOrEmpty(fc["OnlyChairs"]) && !string.IsNullOrWhiteSpace(fc["OnlyChairs"]) &&
                                !string.IsNullOrEmpty(fc["Sofas"]) && !string.IsNullOrWhiteSpace(fc["Sofas"]) &&
                                !string.IsNullOrEmpty(fc["InvitationCard"]) && !string.IsNullOrWhiteSpace(fc["InvitationCard"]) &&
                                 !string.IsNullOrEmpty(fc["IdentityCard"]) && !string.IsNullOrWhiteSpace(fc["IdentityCard"]))
                            {
                                if (System.DateTime.Now < Convert.ToDateTime(fc["BookingDate"]))
                                {
                                    if (DateTime.Today.AddDays(7) < Convert.ToDateTime(fc["BookingDate"]))
                                    {
                                        if (DateTime.Today.AddDays(100) > Convert.ToDateTime(fc["BookingDate"]))
                                        {
                                            int a = 2000;
                                            int b = 0;
                                            int c = Convert.ToInt32(fc["NoOfGuest"]);
                                            if (( c <= a)&&( c > b))
                                            {
                                                int intEvent = Convert.ToInt32(Session["EventID"]);
                                                //tbl_Events tblevents = Session["EventID"] as tbl_Events;
                                                Book_Event objEvent = new Book_Event();
                                                objEvent.EventID = intEvent;
                                                objEvent.BookingDate = Convert.ToDateTime(fc["BookingDate"]);
                                                objEvent.NoOfGuest = Convert.ToInt32(fc["NoOfGuest"]);
                                                objEvent.VenueType = fc["VenueType"];
                                                objEvent.DJ = fc["DJ"];
                                                objEvent.Speakers = fc["Speakers"];
                                                objEvent.Mikes = fc["Mikes"];
                                                objEvent.NormalSounds = fc["NormalSounds"];
                                                objEvent.Banjo = fc["Banjo"];
                                                objEvent.Lejms = fc["Lejms"];
                                                objEvent.Band = fc["Band"];
                                                objEvent.Orchestra = fc["Orchestra"];
                                                objEvent.Snacks = fc["Snacks"];
                                                objEvent.FoodType = fc["FoodType"];
                                                objEvent.Flower = fc["Flower"];
                                                objEvent.Clothes = fc["Clothes"];
                                                objEvent.Balloons = fc["Balloons"];
                                                objEvent.Lights = fc["Lights"];
                                                objEvent.ChairWithCover = fc["ChairWithCover"];
                                                objEvent.OnlyChairs = fc["OnlyChairs"];
                                                objEvent.Sofas = fc["Sofas"];
                                                objEvent.Tables = fc["Tables"];
                                                objEvent.InvitationCard = fc["InvitationCard"];
                                                objEvent.IdentityCard = fc["IdentityCard"];
                                                if (ModelState.IsValid)
                                                {

                                                    db.Book_Event.Add(objEvent);
                                                    db.SaveChanges();
                                                    using (MailMessage mm = new MailMessage())
                                                    {
                                                        string From = "dabevents21225@gmail.com";
                                                        mm.From = new MailAddress(From, "DAB Events");
                                                        mm.To.Add(User.Identity.Name);
                                                        mm.Subject = "Event Booking is confirmed";
                                                        mm.IsBodyHtml = true;
                                                        mm.Body = "Dear &nbsp;" + User.Identity.Name + "&nbsp; Thankyou for booking the event we will soon get in touch with you within 48 hours";

                                                        SmtpClient smtp = new SmtpClient();
                                                        smtp.Host = "smtp.gmail.com";
                                                        smtp.EnableSsl = true;
                                                        string UserName = "dabevents21225@gmail.com";
                                                        string Password = "@dabevents21225";
                                                        NetworkCredential network = new NetworkCredential(UserName, Password);
                                                        smtp.UseDefaultCredentials = true;
                                                        smtp.Credentials = network;
                                                        smtp.Port = 587;
                                                        smtp.Send(mm);
                                                    }
                                                    return RedirectToAction("EventIndex");
                                                    HttpContext.Session.Remove("EventID");

                                                }
                                            }
                                            else
                                            {
                                                ViewBag.Mg = ("Guest cannot be less than 1 and more than 2000");
                                            }
                                        }
                                        else
                                        {
                                            ViewBag.Msg = ("Event can be done before 3 months.");
                                        }
                                    }
                                    else
                                    {
                                        ViewBag.Messg = ("your event can be book after a week.");
                                    }
                                }
                                else
                                {
                                    ViewBag.Mssg = ("Event Date cannot be privious date.");
                                }
                            }


                            else
                            {
                                ModelState.AddModelError("", "");
                                return View();
                            }

                            
                return View();
            }
        }
        
        



        }
    
}
