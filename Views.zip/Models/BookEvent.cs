﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DABEvents.Models
{
    public class BookEvent
    {
       
        public int BookingID { get; set; }
     
        public int EventID { get; set; }
        [Required(ErrorMessage = "Required")]
        [Display(Name = "Venue Type")]
        public string VenueType { get; set; }

        [Required(ErrorMessage = "Required")]
        [Display(Name = "No. of Guest")]
        [Range(1,2000,ErrorMessage="guest cannot be less than 1 and more than 2000")]
        public int NoOfGuest { get; set; }

        [Display(Name = "Date of Booking")]
        [DataType(DataType.Date)]
        [Required(ErrorMessage = "Required")]
        public System.DateTime BookingDate { get; set; }

        [Required(ErrorMessage = "Required")]
        public string DJ { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Speakers { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Mikes { get; set; }

        [Required(ErrorMessage = "Required")]
        [Display(Name = "Normal Sounds")]
        public string NormalSounds { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Banjo { get; set; }

        [Required(ErrorMessage = "Required")]
        [Display(Name = "Lejims")]
        public string Lejms { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Band { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Orchestra { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Snacks { get; set; }

        [Required(ErrorMessage = "Required")]
        [Display(Name = "Food Type")]
        public string FoodType { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Flower { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Clothes { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Balloons { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Lights { get; set; }

        [Required(ErrorMessage = "Required")]
        [Display(Name = "Chair With Cover")]
        public string ChairWithCover { get; set; }

        [Required(ErrorMessage = "Required")]
        [Display(Name = "Only Chairs")]
        public string OnlyChairs { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Sofas { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Tables { get; set; }

        [Required(ErrorMessage = "Required")]
        [Display(Name = "Invitation Card")]
        public string InvitationCard { get; set; }

        [Required(ErrorMessage = "Required")]
        [Display(Name = "Identity Card")]
        public string IdentityCard { get; set; }
        //public int EventID { get; set; }
    
        public string UserID { get; set; }
       
        public string EventType { get; set; }
    }

}