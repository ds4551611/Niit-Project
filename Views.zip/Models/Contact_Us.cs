﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DABEvents.Models
{
    public class Contact_Us:Contact_Form
    {
        [Required(AllowEmptyStrings = false, ErrorMessage = "Name required")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Please use letters only")]
        public string Name { get; set; }
        
        [Required(AllowEmptyStrings = false, ErrorMessage = "Email ID required")]
        [DataType(DataType.EmailAddress)]
        public string EmailID { get; set; }
       
        [Required(AllowEmptyStrings=false, ErrorMessage = "Phone No. required")]
        [StringLength(10,ErrorMessage="The Mobile must contain 10 digits",MinimumLength=10)]
        public string Phone { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Message required")]
        public string Message { get; set; }
       
    }
}