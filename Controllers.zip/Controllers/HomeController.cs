﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BADEvents.Models;
using Microsoft.Ajax.Utilities;
using DABEvents.Models;
using System.Net.Mail;
using System.Net;

namespace BADEvents.Controllers
{
    public class HomeController : Controller
    {
        DABEventsEntities db = new DABEventsEntities();

        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View();
        }

        public ActionResult Gallery()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult BookEvents()
        {
            ViewBag.Message = "your bookevents page";
            return View();
        }

        public ActionResult AddEventName(string EventName)
        {
            DABEventsEntities db = new DABEventsEntities();

            tbl_Events objEvents = new tbl_Events();

            objEvents.UserID = User.Identity.Name;
            objEvents.EventType = EventName;
            db.tbl_Events.Add(objEvents);
            db.SaveChanges();
            Session["EventID"] = objEvents.EventID;
            //List<tbl_Events> q = (from s in db.tbl_Events where s.EventType == EventName && s.UserID == User.Identity.Name select s).ToList();

            //foreach (var objEven in q)
            //{

            //    //Session["EventID"] = objEven.EventID;
            //    //HttpContext.Session.Add("EventID", objEvents);

            //    //Book_Event objEvent = new Book_Event();
            //    //objEvent.EventID = objEven.EventID;
            //    //objEvent.BookingDate = DateTime.Now;
            //    //objEvent.NoOfGuest = 0;
            //    //objEvent.VenueType = "";
            //    //objEvent.DJ = "";
            //    //objEvent.Speakers = "";
            //    //objEvent.Mikes = "";
            //    //objEvent.NormalSounds = "";
            //    //objEvent.Banjo = "";
            //    //objEvent.Lejms = "";
            //    //objEvent.Band = "";
            //    //objEvent.Orchestra = "";
            //    //objEvent.Snacks = "";
            //    //objEvent.FoodType = "";
            //    //objEvent.Flower = "";
            //    //objEvent.Clothes = "";
            //    //objEvent.Balloons = "";
            //    //objEvent.Lights = "";
            //    //objEvent.ChairWithCover = "";
            //    //objEvent.OnlyChairs = "";
            //    //objEvent.Sofas = "";
            //    //objEvent.Tables = "";
            //    //objEvent.InvitationCard = "";
            //    //objEvent.IdentityCard = "";
            //    //db.Book_Event.Add(objEvent);
            //    //db.SaveChanges();
            //}



            return RedirectToAction("BookEvent", "BookEvent");

        }






        public ActionResult Contact()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Contact(FormCollection fc)
        {
         Contact_Form cont=new Contact_Form();
           
            if(!string.IsNullOrEmpty(fc["Name"]) && !string.IsNullOrWhiteSpace(fc["Name"]) &&
                !string.IsNullOrEmpty(fc["EmailID"]) && !string.IsNullOrWhiteSpace(fc["EmailID"]) &&
                !string.IsNullOrEmpty(fc["Phone"]) && !string.IsNullOrWhiteSpace(fc["Phone"])&&
                !string.IsNullOrEmpty(fc["Message"]) && !string.IsNullOrWhiteSpace(fc["Message"]))
            {
                if (fc["Phone"].Length == 10)
                {
                    cont.Name = fc["Name"];
                    cont.EmailID = fc["EmailID"];
                    cont.Phone = fc["Phone"];
                    cont.Message = fc["Message"];
                    cont.Date = System.DateTime.Now;
                    db.Contact_Form.Add(cont);
                    db.SaveChanges();
                }
                else { ViewBag.Mssg ="Enter valid phone number";
                return View();
                }
                using (MailMessage mm = new MailMessage())
                {
                    string From = "dabevents21225@gmail.com";
                    mm.From = new MailAddress(From,"DAB Events");
                    mm.To.Add (fc["EmailID"].ToString());
                    mm.Subject = "Thankyou for Contacting Us";
                    mm.IsBodyHtml = true;
                    mm.Body = "Dear" + fc["Name"] + "Thankyou for contacting us we will soon get in touch with you within 48 hours";
                   
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.EnableSsl = true;
                    string UserName = "dabevents21225@gmail.com";
                    string Password = "@dabevents21225";
                    NetworkCredential network = new NetworkCredential(UserName, Password);
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = network;
                    smtp.Port = 587;
                    smtp.Send(mm);
                }
            }

            else
            {
            ModelState.AddModelError("","");
                return View();
            
            }

            
            return RedirectToAction("Index","Home");
        }

    }
}

       



            
          
    


